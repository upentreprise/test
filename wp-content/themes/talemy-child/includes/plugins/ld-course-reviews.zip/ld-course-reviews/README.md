# ld-course-reviews
LearnDash Course Reviews plugin



## Changelog

1.0.4 - 2019-09-28
* New: Single review template
* New: Added option to display reviews after course content
* Tweak: CSS style update
* Update: Templates

1.0.3 - 2019-08-25
* New: RTL support.
* New: Shortcodes: [ldcr_course_reviews], [ldcr_course_rating], [ldcr_course_rating_summary]
* Tweak: CSS style update
* Fix: AJAX pagination

1.0.0
* Initial release